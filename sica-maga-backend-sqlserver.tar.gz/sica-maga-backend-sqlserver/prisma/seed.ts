import bcrypt from 'bcryptjs';
import { PrismaClient, RolNombre } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const roles = [
    [RolNombre.SUPERADMIN, 'Acceso institucional total'],
    [RolNombre.TECNICO_CAMPO, 'Registro y actualización de información de campo'],
    [RolNombre.CONSULTOR_AUDITOR, 'Consulta de reportes y estadísticas']
  ] as const;

  for (const [nombre, descripcion] of roles) {
    await prisma.rol.upsert({ where: { nombre }, update: { descripcion }, create: { nombre, descripcion } });
  }

  const superAdmin = await prisma.rol.findUniqueOrThrow({ where: { nombre: RolNombre.SUPERADMIN } });
  const passwordHash = await bcrypt.hash('CambiarPassword123!', 12);
  await prisma.usuario.upsert({
    where: { correo: 'admin@sica-maga.local' },
    update: {},
    create: {
      nombreCompleto: 'Administrador SICA-MAGA',
      correo: 'admin@sica-maga.local',
      passwordHash,
      rolId: superAdmin.id
    }
  });

  console.log('Seed completado. Usuario: admin@sica-maga.local / CambiarPassword123!');
  console.log('IMPORTANTE: cambiar la contraseña antes de cualquier uso real.');
}

main().catch((error) => { console.error(error); process.exit(1); }).finally(() => prisma.$disconnect());
