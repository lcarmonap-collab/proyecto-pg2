import bcrypt from 'bcryptjs';
import jwt, { SignOptions } from 'jsonwebtoken';
import crypto from 'node:crypto';
import { env } from '../config/env';
import { prisma } from '../config/prisma';
import { AppError } from '../utils/AppError';
import { UsuarioRepository } from '../repositories/usuario.repository';
import { LoginDto } from '../schemas/auth.schema';
import { JwtAccessPayload, JwtRefreshPayload } from '../types/auth';

export class AuthService {
  constructor(private readonly usuarios = new UsuarioRepository()) {}

  async login(dto: LoginDto) {
    const usuario = await this.usuarios.findByCorreo(dto.correo.toLowerCase());
    if (!usuario || !usuario.activo) throw new AppError(401, 'AUTH_INVALID', 'Credenciales inválidas.');
    const valid = await bcrypt.compare(dto.password, usuario.passwordHash);
    if (!valid) throw new AppError(401, 'AUTH_INVALID', 'Credenciales inválidas.');

    const accessPayload: JwtAccessPayload = { sub: String(usuario.id), email: usuario.correo, role: usuario.rol.nombre, type: 'access' };
    const refreshPayload: JwtRefreshPayload = { sub: String(usuario.id), type: 'refresh' };
    const accessToken = jwt.sign(accessPayload, env.JWT_ACCESS_SECRET, { expiresIn: env.ACCESS_TOKEN_EXPIRES_IN as SignOptions['expiresIn'] });
    const refreshToken = jwt.sign(refreshPayload, env.JWT_REFRESH_SECRET, { expiresIn: env.REFRESH_TOKEN_EXPIRES_IN as SignOptions['expiresIn'] });
    const tokenHash = this.hashToken(refreshToken);
    await prisma.refreshToken.create({ data: { usuarioId: usuario.id, tokenHash, expiresAt: this.refreshExpiry() } });

    return {
      accessToken,
      refreshToken,
      usuario: { id: usuario.id, nombreCompleto: usuario.nombreCompleto, correo: usuario.correo, rol: usuario.rol.nombre }
    };
  }

  async refresh(refreshToken: string) {
    let payload: JwtRefreshPayload;
    try { payload = jwt.verify(refreshToken, env.JWT_REFRESH_SECRET) as JwtRefreshPayload; }
    catch { throw new AppError(401, 'REFRESH_INVALID', 'Refresh token inválido o expirado.'); }
    if (payload.type !== 'refresh') throw new AppError(401, 'REFRESH_INVALID', 'Tipo de token inválido.');
    const tokenHash = this.hashToken(refreshToken);
    const stored = await prisma.refreshToken.findUnique({ where: { tokenHash }, include: { usuario: { include: { rol: true } } } });
    if (!stored || stored.revokedAt || stored.expiresAt < new Date() || !stored.usuario.activo) throw new AppError(401, 'REFRESH_INVALID', 'Refresh token inválido o expirado.');
    await prisma.refreshToken.update({ where: { id: stored.id }, data: { revokedAt: new Date() } });
    return this.loginWithUser(stored.usuario);
  }

  async logout(refreshToken: string) {
    const tokenHash = this.hashToken(refreshToken);
    await prisma.refreshToken.updateMany({ where: { tokenHash, revokedAt: null }, data: { revokedAt: new Date() } });
  }

  async me(id: number) {
    const usuario = await this.usuarios.findById(id);
    if (!usuario || !usuario.activo) throw new AppError(404, 'USER_NOT_FOUND', 'Usuario no encontrado.');
    return { id: usuario.id, nombreCompleto: usuario.nombreCompleto, correo: usuario.correo, rol: usuario.rol.nombre };
  }

  private async loginWithUser(usuario: Awaited<ReturnType<UsuarioRepository['findByCorreo']>>) {
    if (!usuario) throw new AppError(401, 'AUTH_INVALID', 'Usuario no disponible.');
    const accessPayload: JwtAccessPayload = { sub: String(usuario.id), email: usuario.correo, role: usuario.rol.nombre, type: 'access' };
    const refreshPayload: JwtRefreshPayload = { sub: String(usuario.id), type: 'refresh' };
    const accessToken = jwt.sign(accessPayload, env.JWT_ACCESS_SECRET, { expiresIn: env.ACCESS_TOKEN_EXPIRES_IN as SignOptions['expiresIn'] });
    const refreshToken = jwt.sign(refreshPayload, env.JWT_REFRESH_SECRET, { expiresIn: env.REFRESH_TOKEN_EXPIRES_IN as SignOptions['expiresIn'] });
    await prisma.refreshToken.create({ data: { usuarioId: usuario.id, tokenHash: this.hashToken(refreshToken), expiresAt: this.refreshExpiry() } });
    return { accessToken, refreshToken, usuario: { id: usuario.id, nombreCompleto: usuario.nombreCompleto, correo: usuario.correo, rol: usuario.rol.nombre } };
  }

  private hashToken(token: string) { return crypto.createHash('sha256').update(token).digest('hex'); }
  private refreshExpiry() { const d = new Date(); d.setDate(d.getDate() + 7); return d; }
}
