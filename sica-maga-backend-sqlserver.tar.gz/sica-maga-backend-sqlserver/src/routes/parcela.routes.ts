import { Router } from 'express';
import { RolNombre } from '@prisma/client';
import { ParcelaController } from '../controllers/parcela.controller';
import { authenticateJWT, authorizeRoles } from '../middlewares/auth.middleware';

const router = Router();
const controller = new ParcelaController();
router.use(authenticateJWT);
router.get('/', controller.list);
router.get('/:id', controller.get);
router.post('/', authorizeRoles(RolNombre.SUPERADMIN, RolNombre.TECNICO_CAMPO), controller.create);
router.put('/:id', authorizeRoles(RolNombre.SUPERADMIN, RolNombre.TECNICO_CAMPO), controller.update);
router.delete('/:id', authorizeRoles(RolNombre.SUPERADMIN), controller.remove);
export default router;
