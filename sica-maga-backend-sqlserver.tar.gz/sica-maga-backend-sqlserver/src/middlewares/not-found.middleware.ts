import { Request, Response } from 'express';
export function notFound(_req: Request, res: Response) { res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Recurso no encontrado.' } }); }
