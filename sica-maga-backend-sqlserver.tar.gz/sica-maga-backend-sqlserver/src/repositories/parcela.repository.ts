import { Prisma } from '@prisma/client';
import { prisma } from '../config/prisma';
import { CreateParcelaDto, ParcelaQuery, UpdateParcelaDto } from '../schemas/parcela.schema';

export class ParcelaRepository {
  async list(query: ParcelaQuery) {
    const { page, limit, codigo, productorId, departamentoId, municipioId, sortBy, sortOrder } = query;
    const where: Prisma.ParcelaWhereInput = {
      activo: true,
      ...(codigo ? { codigo: { contains: codigo } } : {}),
      ...(productorId ? { productorId } : {}),
      ...(departamentoId ? { departamentoId } : {}),
      ...(municipioId ? { municipioId } : {})
    };
    const [items, total] = await prisma.$transaction([
      prisma.parcela.findMany({
        where,
        include: { productor: true, departamento: true, municipio: true },
        orderBy: { [sortBy]: sortOrder },
        skip: (page - 1) * limit,
        take: limit
      }),
      prisma.parcela.count({ where })
    ]);
    return { items, total, page, limit, totalPages: Math.ceil(total / limit) };
  }

  findById(id: number) {
    return prisma.parcela.findFirst({
      where: { id, activo: true },
      include: { productor: true, departamento: true, municipio: true, cosechas: true }
    });
  }

  findByCodigo(codigo: string) {
    return prisma.parcela.findUnique({ where: { codigo } });
  }

  create(data: CreateParcelaDto) {
    return prisma.parcela.create({ data });
  }

  update(id: number, data: UpdateParcelaDto) {
    return prisma.parcela.update({ where: { id }, data });
  }

  softDelete(id: number) {
    return prisma.parcela.update({ where: { id }, data: { activo: false } });
  }
}
