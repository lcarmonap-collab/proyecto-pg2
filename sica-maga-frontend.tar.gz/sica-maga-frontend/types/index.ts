export type Role = 'SUPERADMIN' | 'TECNICO_CAMPO' | 'CONSULTOR_AUDITOR';

export interface Usuario {
  idUsuario: number;
  nombreCompleto: string;
  usuario: string;
  correo?: string;
  rol: Role;
  departamentoId?: number;
  municipioId?: number;
  estado: boolean;
}

export interface AuthResponse {
  token: string;
  usuario: Usuario;
}

export interface Productor {
  idProductor: number;
  idComunidad: number;
  nombres: string;
  apellidos: string;
  dpi?: string;
  telefono?: string;
  correo?: string;
  direccion?: string;
  genero?: 'Masculino' | 'Femenino' | 'Otro';
  fechaNacimiento?: string;
  cooperativa?: string;
  fechaRegistro: string;
  estado: boolean;
  comunidad?: string;
  municipio?: string;
  departamento?: string;
}

export interface ProductorListResponse {
  data: Productor[];
  meta: { page: number; limit: number; total: number; totalPages: number };
}

export interface Parcela {
  idParcela: number;
  idProductor: number;
  nombreParcela: string;
  areaHectareas: number;
  areaManzanas?: number;
  latitud?: number;
  longitud?: number;
  altitudMetros?: number;
  tipoSuelo?: string;
  sistemaRiego?: string;
  tenenciaTierra?: 'Propia' | 'Arrendada' | 'Comunal' | 'Otra';
  estado: boolean;
  productor?: string;
}

export interface Cultivo {
  idCultivo: number;
  idTipoCultivo: number;
  nombreCultivo: string;
  unidadMedida: string;
  estado: boolean;
}

export interface ProgramaApoyo {
  idPrograma: number;
  nombrePrograma: string;
  descripcion?: string;
  tipoPrograma?: string;
  fechaInicio?: string;
  fechaFin?: string;
  estado: boolean;
}

export interface ApiResponse<T> {
  success: boolean;
  data: T;
  message?: string;
}
