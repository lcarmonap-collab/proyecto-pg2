import { z } from 'zod';

export const loginSchema = z.object({
  usuario: z.string().min(3, 'El usuario debe tener al menos 3 caracteres').max(50),
  password: z.string().min(8, 'La contraseña debe tener al menos 8 caracteres').max(100),
});

export type LoginForm = z.infer<typeof loginSchema>;
