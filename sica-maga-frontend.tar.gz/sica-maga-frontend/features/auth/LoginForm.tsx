'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { loginSchema, type LoginForm as LoginValues } from '@/schemas/auth.schema';
import { useAuth } from './auth-context';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';

export function LoginForm() {
  const { login } = useAuth();
  const [serverError, setServerError] = useState('');
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<LoginValues>({ resolver: zodResolver(loginSchema) });

  const onSubmit = async (data: LoginValues) => {
    setServerError('');
    try { await login(data); } catch (error: any) { setServerError(error?.response?.data?.message ?? 'No fue posible iniciar sesión.'); }
  };

  return <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
    <div><label className="mb-1 block text-sm font-medium">Usuario</label><Input {...register('usuario')} autoComplete="username" />{errors.usuario && <p className="mt-1 text-xs text-red-600">{errors.usuario.message}</p>}</div>
    <div><label className="mb-1 block text-sm font-medium">Contraseña</label><Input {...register('password')} type="password" autoComplete="current-password" />{errors.password && <p className="mt-1 text-xs text-red-600">{errors.password.message}</p>}</div>
    {serverError && <div role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{serverError}</div>}
    <Button className="w-full" disabled={isSubmitting}>{isSubmitting ? 'Ingresando...' : 'Iniciar sesión'}</Button>
  </form>;
}
