'use client';

import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { authService } from '@/services/auth.service';
import type { Role, Usuario } from '@/types';
import type { LoginForm } from '@/schemas/auth.schema';

interface AuthContextValue {
  user: Usuario | null;
  token: string | null;
  loading: boolean;
  login: (payload: LoginForm) => Promise<void>;
  logout: () => void;
  hasRole: (...roles: Role[]) => boolean;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [user, setUser] = useState<Usuario | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const storedToken = sessionStorage.getItem('sica_maga_token');
    const storedUser = sessionStorage.getItem('sica_maga_user');
    if (storedToken && storedUser) {
      setToken(storedToken);
      setUser(JSON.parse(storedUser) as Usuario);
    }
    setLoading(false);

    const handler = () => logout();
    window.addEventListener('sica-maga:unauthorized', handler);
    return () => window.removeEventListener('sica-maga:unauthorized', handler);
  }, []);

  const login = async (payload: LoginForm) => {
    const result = await authService.login(payload);
    sessionStorage.setItem('sica_maga_token', result.token);
    sessionStorage.setItem('sica_maga_user', JSON.stringify(result.usuario));
    setToken(result.token);
    setUser(result.usuario);
    router.replace('/dashboard');
  };

  const logout = () => {
    sessionStorage.removeItem('sica_maga_token');
    sessionStorage.removeItem('sica_maga_user');
    setToken(null);
    setUser(null);
    router.replace('/login');
  };

  const value = useMemo(() => ({
    user, token, loading, login, logout,
    hasRole: (...roles: Role[]) => !!user && roles.includes(user.rol),
  }), [user, token, loading]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth debe utilizarse dentro de AuthProvider');
  return context;
}
