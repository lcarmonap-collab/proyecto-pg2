import type { InputHTMLAttributes } from 'react';

export function Input({ className = '', ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return <input className={`w-full rounded-lg border border-slate-300 bg-white px-3 py-2 outline-none focus:border-maga-green focus:ring-2 focus:ring-maga-green/20 ${className}`} {...props} />;
}
